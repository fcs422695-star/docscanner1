const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const { fork } = require('child_process');

let mainWindow;
let apiProcess;
const API_PORT = 7823;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#0f0f13',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
    },
    icon: path.join(__dirname, '../assets/icon.png'),
    show: false,
  });

  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Custom menu
  Menu.setApplicationMenu(null);

  mainWindow.on('closed', () => {
    mainWindow = null;
    if (apiProcess) apiProcess.kill();
  });
}

function startAPIServer() {
  const apiPath = path.join(__dirname, '../api/server.js');
  if (fs.existsSync(apiPath)) {
    apiProcess = fork(apiPath, [], {
      env: { ...process.env, PORT: API_PORT },
      silent: true,
    });
    apiProcess.stdout.on('data', d => console.log('[API]', d.toString()));
    apiProcess.stderr.on('data', d => console.error('[API ERR]', d.toString()));
  }
}

app.whenReady().then(() => {
  startAPIServer();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (apiProcess) apiProcess.kill();
  if (process.platform !== 'darwin') app.quit();
});

// IPC Handlers
ipcMain.handle('window-minimize', () => mainWindow.minimize());
ipcMain.handle('window-maximize', () => {
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.handle('window-close', () => {
  if (apiProcess) apiProcess.kill();
  mainWindow.close();
});

ipcMain.handle('save-file', async (event, { defaultName, filters, data }) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: defaultName,
    filters,
  });
  if (!result.canceled && result.filePath) {
    const buffer = Buffer.from(data, 'base64');
    fs.writeFileSync(result.filePath, buffer);
    return { success: true, path: result.filePath };
  }
  return { success: false };
});

ipcMain.handle('open-file', async (event, filters) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: filters || [
      { name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'bmp', 'webp', 'tiff'] },
    ],
  });
  if (!result.canceled) {
    const files = result.filePaths.map(fp => ({
      path: fp,
      name: path.basename(fp),
      data: fs.readFileSync(fp).toString('base64'),
      ext: path.extname(fp).toLowerCase().slice(1),
    }));
    return files;
  }
  return [];
});

ipcMain.handle('get-api-port', () => API_PORT);
ipcMain.handle('open-external', (event, url) => shell.openExternal(url));

ipcMain.handle('read-file', (event, filePath) => {
  try {
    return fs.readFileSync(filePath).toString('base64');
  } catch (e) {
    return null;
  }
});
