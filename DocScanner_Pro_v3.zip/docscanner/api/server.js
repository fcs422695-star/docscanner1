/**
 * DocScanner Pro - Local REST API Server
 * Provides document scanning, enhancement, and PDF export endpoints
 */

const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 7823;

// Temp directory for processed files
const TEMP_DIR = path.join(require('os').tmpdir(), 'docscanner_pro');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use('/output', express.static(TEMP_DIR));

const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

// ============================================
// UTILITY FUNCTIONS
// ============================================

async function loadJimp() {
  try { return require('jimp'); } catch(e) { return null; }
}

async function processImageBuffer(buffer, options = {}) {
  const Jimp = await loadJimp();
  if (!Jimp) throw new Error('Image processing library not available');

  const image = await Jimp.read(buffer);
  const {
    brightness = 0,
    contrast = 0,
    mode = 'color',
    rotate = 0,
    flipH = false,
    flipV = false,
    quality = 85,
    sharpen = false,
    blur = 0,
    crop = null,
  } = options;

  // Rotate
  if (rotate !== 0) image.rotate(-rotate);

  // Flip
  if (flipH) image.flip(true, false);
  if (flipV) image.flip(false, true);

  // Crop
  if (crop && crop.x !== undefined) {
    image.crop(
      Math.max(0, Math.round(crop.x)),
      Math.max(0, Math.round(crop.y)),
      Math.max(10, Math.round(crop.width)),
      Math.max(10, Math.round(crop.height))
    );
  }

  // Brightness: jimp range is -1 to +1, we accept -100 to +100
  if (brightness !== 0) image.brightness(brightness / 100);

  // Contrast: jimp range is -1 to +1
  if (contrast !== 0) image.contrast(contrast / 100);

  // Sharpen
  if (sharpen) image.convolute([[0,-1,0],[-1,5,-1],[0,-1,0]]);

  // Blur
  if (blur > 0) image.blur(blur);

  // Modes
  if (mode === 'grayscale' || mode === 'bw') {
    image.grayscale();
    if (mode === 'bw') {
      // Threshold for black & white
      image.scan(0, 0, image.bitmap.width, image.bitmap.height, function(x, y, idx) {
        const gray = this.bitmap.data[idx];
        const bw = gray < 128 ? 0 : 255;
        this.bitmap.data[idx] = bw;
        this.bitmap.data[idx + 1] = bw;
        this.bitmap.data[idx + 2] = bw;
      });
    }
  }

  if (mode === 'magic') {
    // Magic color mode: enhance + auto-contrast
    image.normalize().color([{ apply: 'saturate', params: [30] }]);
  }

  const outputBuffer = await image.quality(quality).getBufferAsync(Jimp.MIME_JPEG);
  return outputBuffer;
}

async function bufferToPDF(imageBuffers, outputPath, options = {}) {
  try {
    const PDFDocument = require('pdfkit');
    const { pageSize = 'A4', margin = 20 } = options;

    const pageSizes = {
      'A4': [595.28, 841.89],
      'Letter': [612, 792],
      'Legal': [612, 1008],
    };

    const [pw, ph] = pageSizes[pageSize] || pageSizes['A4'];

    const doc = new PDFDocument({ autoFirstPage: false, margin: 0 });
    const writeStream = fs.createWriteStream(outputPath);
    doc.pipe(writeStream);

    for (const imgBuf of imageBuffers) {
      doc.addPage({ size: [pw, ph], margin: 0 });
      const usableW = pw - margin * 2;
      const usableH = ph - margin * 2;
      doc.image(imgBuf, margin, margin, {
        fit: [usableW, usableH],
        align: 'center',
        valign: 'center',
      });
    }

    doc.end();

    return new Promise((resolve, reject) => {
      writeStream.on('finish', () => resolve(outputPath));
      writeStream.on('error', reject);
    });
  } catch (err) {
    throw new Error('PDF generation failed: ' + err.message);
  }
}

// ============================================
// API ROUTES
// ============================================

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    name: 'DocScanner Pro API',
    version: '1.0.0',
    port: PORT,
    endpoints: [
      'POST /api/enhance    - Enhance document image',
      'POST /api/pdf        - Convert images to PDF',
      'POST /api/batch      - Batch process multiple images',
      'GET  /api/health     - API status',
    ],
  });
});

// Enhance single image
app.post('/api/enhance', upload.single('image'), async (req, res) => {
  try {
    if (!req.file && !req.body.imageBase64) {
      return res.status(400).json({ error: 'No image provided. Use "image" field (multipart) or "imageBase64" (JSON).' });
    }

    let inputBuffer;
    if (req.file) {
      inputBuffer = req.file.buffer;
    } else {
      inputBuffer = Buffer.from(req.body.imageBase64, 'base64');
    }

    const options = {
      brightness: parseFloat(req.body.brightness || 0),
      contrast: parseFloat(req.body.contrast || 0),
      mode: req.body.mode || 'color',
      rotate: parseFloat(req.body.rotate || 0),
      flipH: req.body.flipH === 'true' || req.body.flipH === true,
      flipV: req.body.flipV === 'true' || req.body.flipV === true,
      quality: parseInt(req.body.quality || 85),
      sharpen: req.body.sharpen === 'true' || req.body.sharpen === true,
      blur: parseInt(req.body.blur || 0),
      crop: req.body.crop ? JSON.parse(req.body.crop) : null,
    };

    const outputBuffer = await processImageBuffer(inputBuffer, options);

    const fileId = uuidv4();
    const outputPath = path.join(TEMP_DIR, `${fileId}.jpg`);
    fs.writeFileSync(outputPath, outputBuffer);

    const base64Out = outputBuffer.toString('base64');

    res.json({
      success: true,
      fileId,
      imageBase64: base64Out,
      mimeType: 'image/jpeg',
      url: `/output/${fileId}.jpg`,
      size: outputBuffer.length,
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Convert to PDF
app.post('/api/pdf', async (req, res) => {
  try {
    const { images, pageSize, margin, filename } = req.body;

    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: 'Provide "images" array of base64 strings.' });
    }

    const imageBuffers = images.map(b64 => Buffer.from(b64, 'base64'));
    const fileId = uuidv4();
    const outputPath = path.join(TEMP_DIR, `${fileId}.pdf`);

    await bufferToPDF(imageBuffers, outputPath, { pageSize, margin });

    const pdfBuffer = fs.readFileSync(outputPath);
    const base64PDF = pdfBuffer.toString('base64');

    res.json({
      success: true,
      fileId,
      pdfBase64: base64PDF,
      mimeType: 'application/pdf',
      url: `/output/${fileId}.pdf`,
      pages: images.length,
      size: pdfBuffer.length,
      filename: filename || `scan_${Date.now()}.pdf`,
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Batch enhance multiple images
app.post('/api/batch', upload.array('images', 20), async (req, res) => {
  try {
    const files = req.files;
    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'No images provided.' });
    }

    const options = {
      brightness: parseFloat(req.body.brightness || 0),
      contrast: parseFloat(req.body.contrast || 0),
      mode: req.body.mode || 'color',
      quality: parseInt(req.body.quality || 85),
      sharpen: req.body.sharpen === 'true',
    };

    const results = [];
    for (const file of files) {
      try {
        const processed = await processImageBuffer(file.buffer, options);
        const fileId = uuidv4();
        const outPath = path.join(TEMP_DIR, `${fileId}.jpg`);
        fs.writeFileSync(outPath, processed);
        results.push({
          originalName: file.originalname,
          fileId,
          imageBase64: processed.toString('base64'),
          url: `/output/${fileId}.jpg`,
          size: processed.length,
          success: true,
        });
      } catch (e) {
        results.push({ originalName: file.originalname, success: false, error: e.message });
      }
    }

    res.json({ success: true, results, count: results.length });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Cleanup temp files older than 1 hour
setInterval(() => {
  try {
    const files = fs.readdirSync(TEMP_DIR);
    const now = Date.now();
    files.forEach(f => {
      const fp = path.join(TEMP_DIR, f);
      const stat = fs.statSync(fp);
      if (now - stat.mtimeMs > 3600000) fs.unlinkSync(fp);
    });
  } catch (e) {}
}, 300000);

app.listen(PORT, '127.0.0.1', () => {
  console.log(`DocScanner Pro API running on http://127.0.0.1:${PORT}`);
});

module.exports = app;
